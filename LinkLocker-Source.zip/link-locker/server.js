'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cookieParser = require('cookie-parser');

const store = require('./src/store');
const auth = require('./src/auth');
const telegram = require('./src/telegram');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(auth.attach);
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.disable('x-powered-by');
app.set('trust proxy', true);

/* ------------------------------------------------------------------ *
 * Visitor progress (in-memory)
 * ------------------------------------------------------------------ */
const progress = new Map(); // sid -> { lockerId, done: {taskIndex: true}, clicks: {taskIndex: ts}, telegramUserId }
function getProgress(sid, lockerId) {
  let p = progress.get(sid);
  if (!p || p.lockerId !== lockerId) {
    p = { lockerId, done: {}, clicks: {}, telegramUserId: null, at: Date.now() };
    progress.set(sid, p);
  }
  return p;
}
setInterval(() => {
  const limit = Date.now() - 1000 * 60 * 60 * 12;
  for (const [k, v] of progress) if (v.at < limit) progress.delete(k);
}, 1000 * 60 * 30).unref();

function sid(req, res) {
  let id = req.cookies && req.cookies.lk_sid;
  if (!id) {
    id = crypto.randomBytes(12).toString('hex');
    res.cookie('lk_sid', id, { maxAge: 1000 * 60 * 60 * 12, sameSite: 'lax' });
  }
  return id;
}

/* ------------------------------------------------------------------ *
 * Helpers
 * ------------------------------------------------------------------ */
const TASK_META = {
  telegram_channel: { icon: 'telegram', bn: 'টেলিগ্রাম চ্যানেল', cta: 'চ্যানেলে জয়েন করুন' },
  telegram_group: { icon: 'telegram', bn: 'টেলিগ্রাম গ্রুপ', cta: 'গ্রুপে জয়েন করুন' },
  youtube: { icon: 'youtube', bn: 'ইউটিউব চ্যানেল', cta: 'সাবস্ক্রাইব করুন' },
  website: { icon: 'link', bn: 'ওয়েবসাইট ভিজিট', cta: 'ভিজিট করুন' },
  custom: { icon: 'star', bn: 'কাস্টম টাস্ক', cta: 'সম্পন্ন করুন' }
};

function decorateTask(locker, task, index, botReady) {
  const meta = TASK_META[task.type] || TASK_META.custom;
  const canVerify =
    task.type === 'telegram_channel' || task.type === 'telegram_group'
      ? !!(botReady && task.chatId)
      : false;
  return {
    index,
    type: task.type,
    label: task.label || meta.bn,
    url: task.url || '',
    chatId: task.chatId || '',
    required: task.required !== false,
    icon: meta.icon,
    cta: task.cta || meta.cta,
    mode: canVerify ? 'telegram' : 'click'
  };
}

function publicUrl(req, slug) {
  const proto = req.headers['x-forwarded-proto'] || req.protocol;
  return `${proto}://${req.get('host')}/l/${slug}`;
}

/* ------------------------------------------------------------------ *
 * Public locker page
 * ------------------------------------------------------------------ */
app.get('/l/:slug', (req, res) => {
  const locker = store.getLocker(req.params.slug);
  if (!locker) return res.status(404).render('message', {
    title: 'লিংক পাওয়া যায়নি',
    message: 'এই লকারটি বিদ্যমান নেই অথবা মুছে ফেলা হয়েছে।',
    siteName: store.getSettings().siteName
  });
  if (!locker.active) return res.status(403).render('message', {
    title: 'লকার বন্ধ আছে',
    message: 'অ্যাডমিন এই লকারটি নিষ্ক্রিয় করেছেন।',
    siteName: store.getSettings().siteName
  });

  const s = store.getSettings();
  const botReady = telegram.enabled();
  const id = sid(req, res);
  const p = getProgress(id, locker.id);
  store.bumpVisits(locker.id);

  const tasks = (locker.tasks || []).map((t, i) => decorateTask(locker, t, i, botReady));

  res.render('lock', {
    siteName: s.siteName,
    locker,
    tasks,
    done: p.done,
    countdown: locker.countdown || s.defaultCountdown || 15,
    autoRedirect: locker.autoRedirect ? s.autoRedirectSeconds || 5 : 0,
    botUsername: telegram.botUsername(),
    botReady,
    footerNote: s.footerNote
  });
});

app.get('/', (req, res) => res.redirect('/admin'));

/* ------------------------------------------------------------------ *
 * Public API (visitor)
 * ------------------------------------------------------------------ */
function lockerOr404(req, res) {
  const locker = store.getLocker(req.params.slug);
  if (!locker) {
    res.status(404).json({ ok: false, error: 'লকার পাওয়া যায়নি' });
    return null;
  }
  return locker;
}

// টাস্কে ক্লিক রেজিস্টার (কাউন্টডাউন শুরু)
app.post('/api/l/:slug/click', (req, res) => {
  const locker = lockerOr404(req, res);
  if (!locker) return;
  const i = Number(req.body.taskIndex);
  const p = getProgress(sid(req, res), locker.id);
  p.clicks[i] = Date.now();
  res.json({ ok: true, clickAt: p.clicks[i] });
});

// ক্লিক-ভিত্তিক ভেরিফিকেশন (কাউন্টডাউন শেষে)
app.post('/api/l/:slug/verify-click', (req, res) => {
  const locker = lockerOr404(req, res);
  if (!locker) return;
  const i = Number(req.body.taskIndex);
  const p = getProgress(sid(req, res), locker.id);
  const need = (locker.countdown || 10) * 1000 * 0.8; // ২০% ছাড় — লোডিং টাইম বাঁচাতে
  const clickAt = p.clicks[i];
  if (!clickAt) return res.json({ ok: false, error: 'আগে বাটনে ক্লিক করুন' });
  if (Date.now() - clickAt < need) {
    return res.json({ ok: false, error: 'কিছুক্ষণ অপেক্ষা করুন', retryIn: Math.ceil((need - (Date.now() - clickAt)) / 1000) });
  }
  p.done[i] = true;
  res.json({ ok: true, done: p.done });
});

// টেলিগ্রাম বট দিয়ে ভেরিফিকেশন শুরু
app.post('/api/l/:slug/verify-telegram', (req, res) => {
  const locker = lockerOr404(req, res);
  if (!locker) return;
  if (!telegram.enabled()) return res.json({ ok: false, error: 'টেলিগ্রাম বট কনফিগার করা নেই' });

  const i = Number(req.body.taskIndex);
  const task = (locker.tasks || [])[i];
  if (!task) return res.json({ ok: false, error: 'টাস্ক পাওয়া যায়নি' });

  const p = getProgress(sid(req, res), locker.id);
  const bot = telegram.botUsername();

  // ইতিমধ্যে পরিচিত ইউজার → সরাসরি চেক
  if (p.telegramUserId && task.chatId) {
    telegram.isMember(task.chatId, p.telegramUserId).then((r) => {
      if (r.ok) {
        p.done[i] = true;
        res.json({ ok: true, done: p.done, instant: true });
      } else {
        const code = telegram.newCode();
        res.json({ ok: true, needCode: true, code, botUrl: `https://t.me/${bot}?start=v_${code}`, reason: r.status });
      }
    });
    return;
  }

  if (!bot) return res.json({ ok: false, error: 'বট ইউজারনেম পাওয়া যায়নি — টোকেন ঠিক আছে কিনা চেক করুন' });
  const code = telegram.newCode();
  res.json({ ok: true, needCode: true, code, botUrl: `https://t.me/${bot}?start=v_${code}` });
});

// কোড রিজলভ হয়েছে কিনা (পেজ থেকে পোল করা হয়)
app.get('/api/verify/status/:code', async (req, res) => {
  const locker = store.getLocker(req.query.locker || '');
  const i = Number(req.query.task);
  if (!locker) return res.json({ ok: false, error: 'লকার পাওয়া যায়নি' });
  const task = (locker.tasks || [])[i];
  if (!task) return res.json({ ok: false, error: 'টাস্ক পাওয়া যায়নি' });

  const hit = telegram.getPending(req.params.code);
  if (!hit) return res.json({ ok: true, resolved: false });

  const p = getProgress(sid(req, res), locker.id);
  p.telegramUserId = hit.telegramUserId;
  p.telegramUsername = hit.username;

  const r = await telegram.isMember(task.chatId, hit.telegramUserId);
  telegram.clearPending(req.params.code);
  if (r.ok) {
    p.done[i] = true;
    return res.json({ ok: true, resolved: true, member: true, done: p.done, name: hit.firstName });
  }
  return res.json({ ok: true, resolved: true, member: false, status: r.status, error: r.error });
});

// আনলক
app.post('/api/l/:slug/unlock', (req, res) => {
  const locker = lockerOr404(req, res);
  if (!locker) return;
  const p = getProgress(sid(req, res), locker.id);
  const tasks = locker.tasks || [];
  const pendingIdx = tasks.map((t, i) => (t.required === false ? -1 : i)).filter((i) => i >= 0 && !p.done[i]);
  if (pendingIdx.length) {
    return res.status(400).json({ ok: false, error: 'সব টাস্ক সম্পন্ন করুন', remaining: pendingIdx });
  }
  if (!p.unlocked) {
    store.bumpUnlocks(locker.id, { telegram: p.telegramUsername || '' });
    p.unlocked = true;
    telegram.notifyAdmin(
      '🔓 নতুন আনলক!\n' +
        '📦 লকার: ' + (locker.title || '') + '\n' +
        '👤 ' + (p.telegramUsername ? '@' + p.telegramUsername : 'নাম অজানা') + '\n' +
        '📊 এই লকারে মোট আনলক: ' + (locker.unlocks + 1)
    );
  }
  res.json({ ok: true, url: locker.targetUrl });
});

// প্রগ্রেস (পেজ রিফ্রেশ হলে অগ্রগতি ফিরে আসে)
app.get('/api/l/:slug/progress', (req, res) => {
  const locker = lockerOr404(req, res);
  if (!locker) return;
  const p = getProgress(sid(req, res), locker.id);
  res.json({ ok: true, done: p.done, unlocked: !!p.unlocked, url: p.unlocked ? locker.targetUrl : null, telegramLinked: !!p.telegramUserId });
});

/* ------------------------------------------------------------------ *
 * Admin API
 * ------------------------------------------------------------------ */
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const token = auth.login(username || '', password || '');
  if (!token) return res.status(401).json({ ok: false, error: 'ইউজারনেম বা পাসওয়ার্ড ভুল' });
  res.cookie('lk_admin', token, { maxAge: 1000 * 60 * 60 * 24 * 7, sameSite: 'lax' });
  res.json({ ok: true });
});

app.post('/api/logout', (req, res) => {
  if (req.adminToken) auth.destroySession(req.adminToken);
  res.clearCookie('lk_admin');
  res.json({ ok: true });
});

app.get('/api/state', auth.requireAdmin, (req, res) => {
  const s = store.getSettings();
  const host = req.get('host');
  const proto = req.headers['x-forwarded-proto'] || req.protocol;
  res.json({
    ok: true,
    baseUrl: `${proto}://${host}`,
    settings: {
      siteName: s.siteName,
      adminUsername: s.adminUsername,
      telegramBotToken: s.telegramBotToken ? s.telegramBotToken.replace(/^(.{6}).+(.{4})$/, '$1••••••••$2') : '',
      telegramBotUsername: s.telegramBotUsername,
      hasToken: !!s.telegramBotToken,
      adminChatId: s.adminChatId || '',
      defaultCountdown: s.defaultCountdown,
      autoRedirectSeconds: s.autoRedirectSeconds,
      footerNote: s.footerNote
    },
    telegram: telegram.status(),
    lockers: store.listLockers().map((l) => ({
      ...l,
      url: `${proto}://${host}/l/${l.slug}`,
      taskCount: (l.tasks || []).length,
      rate: l.visits ? Math.round(((l.unlocks || 0) / l.visits) * 100) : 0
    })),
    totals: store.listLockers().reduce(
      (a, l) => ({ visits: a.visits + (l.visits || 0), unlocks: a.unlocks + (l.unlocks || 0), lockers: a.lockers + 1 }),
      { visits: 0, unlocks: 0, lockers: 0 }
    ),
    recent: (store.load().events || []).slice(0, 12)
  });
});

app.post('/api/lockers', auth.requireAdmin, (req, res) => {
  const b = req.body || {};
  if (!b.targetUrl) return res.status(400).json({ ok: false, error: 'টার্গেট লিংক দিন' });
  const locker = store.createLocker(b);
  res.json({ ok: true, locker });
});

app.put('/api/lockers/:id', auth.requireAdmin, (req, res) => {
  const l = store.updateLocker(req.params.id, req.body || {});
  if (!l) return res.status(404).json({ ok: false, error: 'পাওয়া যায়নি' });
  res.json({ ok: true, locker: l });
});

app.delete('/api/lockers/:id', auth.requireAdmin, (req, res) => {
  const ok = store.deleteLocker(req.params.id);
  res.json({ ok });
});

app.post('/api/settings', auth.requireAdmin, async (req, res) => {
  const b = req.body || {};
  const patch = {};
  for (const k of ['siteName', 'telegramBotToken', 'adminChatId', 'defaultCountdown', 'autoRedirectSeconds', 'footerNote', 'adminUsername']) {
    if (k in b) patch[k] = b[k];
  }
  if (b.newPassword) patch.adminPasswordHash = store.hashPassword(b.newPassword);
  if ('telegramBotToken' in b) {
    // getUpdates কনফ্লিক্ট এড়াতে webhook সরিয়ে দেই
    patch.telegramBotToken = String(b.telegramBotToken || '').trim();
  }
  store.updateSettings(patch);
  if ('telegramBotToken' in b) {
    telegram.refreshBotInfo().catch(() => {});
  }
  res.json({ ok: true, telegram: telegram.status() });
});

app.post('/api/telegram/test', auth.requireAdmin, async (req, res) => {
  try {
    const info = await telegram.refreshBotInfo();
    if (!info) return res.json({ ok: false, error: telegram.status().lastError || 'বট সংযোগ হয়নি' });
    res.json({ ok: true, bot: { username: info.username, first_name: info.first_name, id: info.id } });
  } catch (e) {
    res.json({ ok: false, error: e.message });
  }
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.use((req, res) => {
  res.status(404).render('message', {
    title: 'পেজ পাওয়া যায়নি',
    message: '৪০৪ — এই ঠিকানায় কিছু নেই।',
    siteName: store.getSettings().siteName
  });
});

/* ------------------------------------------------------------------ *
 * Boot
 * ------------------------------------------------------------------ */
function seedDemo() {
  const d = store.load();
  if (d.lockers.length) return;
  store.createLocker({
    title: '🎁 এক্সক্লুসিভ বোনাস পেতে নিচের কাজগুলো করুন',
    description: 'নিচের ৩টি কাজ সম্পন্ন করলেই গোপন লিংকটি আনলক হয়ে যাবে।',
    targetUrl: 'https://example.com/secret-download',
    countdown: 15,
    autoRedirect: false,
    tasks: [
      {
        type: 'telegram_channel',
        label: 'টেলিগ্রাম চ্যানেলে সাবস্ক্রাইব করুন',
        url: 'https://t.me/durov',
        chatId: '@durov',
        required: true
      },
      {
        type: 'youtube',
        label: 'ইউটিউব চ্যানেল সাবস্ক্রাইব করুন',
        url: 'https://www.youtube.com/@MrBeast?sub_confirmation=1',
        required: true
      },
      {
        type: 'telegram_group',
        label: 'টেলিগ্রাম গ্রুপে জয়েন করুন',
        url: 'https://t.me/telegram',
        chatId: '@telegram',
        required: true
      }
    ]
  });
  console.log('[seed] ডেমো লকার তৈরি হয়েছে → /l/ খুঁজুন অ্যাডমিন প্যানেলে');
}

seedDemo();
telegram.start();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  🔒 Link Locker চালু আছে`);
  console.log(`  ➜  লোকাল:   http://localhost:${PORT}`);
  console.log(`  ➜  অ্যাডমিন: http://localhost:${PORT}/admin  (ইউজার: admin / পাস: ${process.env.ADMIN_PASSWORD && 'env থেকে' || 'admin123'})\n`);
});

process.on('SIGTERM', () => store.flush());
process.on('SIGINT', () => { store.flush(); process.exit(0); });
