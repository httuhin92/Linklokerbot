/* Link Locker — Admin panel */
(function () {
  var $ = function (s) { return document.querySelector(s); };
  var state = null;
  var editingId = null;

  var TYPES = [
    { v: 'telegram_channel', t: 'টেলিগ্রাম চ্যানেল সাবস্ক্রাইব' },
    { v: 'telegram_group', t: 'টেলিগ্রাম গ্রুপ জয়েন' },
    { v: 'youtube', t: 'ইউটিউব সাবস্ক্রাইব' },
    { v: 'website', t: 'ওয়েবসাইট ভিজিট' },
    { v: 'custom', t: 'কাস্টম টাস্ক' }
  ];

  function toast(msg, kind) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast show' + (kind ? ' ' + kind : '');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.className = 'toast'; }, 2800);
  }

  function api(url, opts) {
    return fetch(url, Object.assign({
      headers: { 'content-type': 'application/json' },
      credentials: 'same-origin'
    }, opts || {})).then(function (r) {
      return r.json().then(function (j) {
        if (r.status === 401) { showLogin(); throw new Error('unauth'); }
        return j;
      });
    });
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function timeAgo(iso) {
    var d = new Date(iso), s = Math.floor((Date.now() - d.getTime()) / 1000);
    if (s < 60) return s + ' সেকেন্ড আগে';
    if (s < 3600) return Math.floor(s / 60) + ' মিনিট আগে';
    if (s < 86400) return Math.floor(s / 3600) + ' ঘণ্টা আগে';
    return Math.floor(s / 86400) + ' দিন আগে';
  }

  /* ---------------- boot ---------------- */
  function boot() {
    api('/api/state').then(function (s) {
      state = s;
      $('#loginWrap').hidden = true;
      $('#app').hidden = false;
      render(s);
    }).catch(function (e) {
      if (e.message !== 'unauth') showLogin();
      else showLogin();
    });
  }

  function showLogin() {
    $('#app').hidden = true;
    $('#loginWrap').hidden = false;
  }

  function render(s) {
    $('#siteNameTop').textContent = s.settings.siteName || 'Link Locker';
    $('#stLockers').textContent = s.totals.lockers;
    $('#stVisits').textContent = s.totals.visits;
    $('#stUnlocks').textContent = s.totals.unlocks;
    $('#stRate').textContent = s.totals.visits ? Math.round((s.totals.unlocks / s.totals.visits) * 100) + '%' : '0%';

    // settings fields
    $('#setSiteName').value = s.settings.siteName || '';
    $('#setFooter').value = s.settings.footerNote || '';
    $('#setCountdown').value = s.settings.defaultCountdown || 15;
    $('#setRedirect').value = s.settings.autoRedirectSeconds || 0;
    $('#setToken').value = s.settings.telegramBotToken || '';
    $('#setAdminChat').value = s.settings.adminChatId || '';
    $('#setUser').value = s.settings.adminUsername || 'admin';
    $('#setPass').value = '';

    var bs = $('#botStatus');
    if (s.telegram.enabled && s.telegram.botUsername) {
      bs.innerHTML = '✅ বট চালু: <b>@' + esc(s.telegram.botUsername) + '</b>';
      bs.className = 'bot-status small';
      bs.style.color = '#4ade80';
    } else if (s.settings.hasToken) {
      bs.innerHTML = '⚠️ টোকেন আছে কিন্তু সংযোগ হয়নি: ' + esc(s.telegram.lastError || 'অজানা ত্রুটি');
      bs.style.color = '#fbbf24';
    } else {
      bs.innerHTML = 'ℹ️ বট সেট করা নেই — ক্লিক + কাউন্টডাউন মোডে চলছে';
      bs.style.color = '#98a0c2';
    }

    renderLockers(s.lockers);
    renderRecent(s.recent);
  }

  function renderLockers(list) {
    var wrap = $('#lockerList');
    $('#emptyState').hidden = list.length > 0;
    wrap.innerHTML = list.map(function (l) {
      var tasks = (l.tasks || []).map(function (t) {
        var cls = t.type && t.type.indexOf('telegram') === 0 ? 'tg' : (t.type === 'youtube' ? 'yt' : '');
        return '<span class="badge ' + cls + '">' + esc(shortType(t.type)) + '</span>';
      }).join(' ');
      return '' +
        '<div class="locker" data-id="' + l.id + '">' +
          '<div class="locker-top">' +
            '<div style="min-width:0">' +
              '<p class="locker-title">' + esc(l.title) + '</p>' +
              '<div class="locker-url">' +
                '<code>' + esc(l.url) + '</code>' +
                '<button class="btn btn-ghost btn-sm" data-act="copy" data-url="' + esc(l.url) + '">কপি</button>' +
              '</div>' +
            '</div>' +
            '<span class="badge ' + (l.active ? 'on' : 'off') + '">' + (l.active ? 'চালু' : 'বন্ধ') + '</span>' +
          '</div>' +
          '<div class="locker-metrics">' +
            '<span>টাস্ক: <b>' + l.taskCount + '</b> ' + tasks + '</span>' +
          '</div>' +
          '<div class="locker-metrics">' +
            '<span>ভিজিট: <b>' + l.visits + '</b></span>' +
            '<span>আনলক: <b>' + l.unlocks + '</b></span>' +
            '<span>কনভার্সন: <b>' + l.rate + '%</b></span>' +
            '<span class="muted">তৈরি: ' + timeAgo(l.createdAt) + '</span>' +
          '</div>' +
          '<div class="locker-actions">' +
            '<button class="btn btn-primary btn-sm" data-act="edit">✏️ এডিট</button>' +
            '<button class="btn btn-ghost btn-sm" data-act="open" data-url="' + esc(l.url) + '">👁️ প্রিভিউ</button>' +
            '<button class="btn btn-ghost btn-sm" data-act="toggle">' + (l.active ? '⏸ নিষ্ক্রিয়' : '▶️ সক্রিয়') + '</button>' +
            '<button class="btn btn-danger btn-sm" data-act="del">🗑 ডিলিট</button>' +
          '</div>' +
        '</div>';
    }).join('');
  }

  function shortType(t) {
    return ({
      telegram_channel: 'TG চ্যানেল',
      telegram_group: 'TG গ্রুপ',
      youtube: 'ইউটিউব',
      website: 'ওয়েবসাইট',
      custom: 'কাস্টম'
    })[t] || 'কাস্টম';
  }

  function renderRecent(events) {
    var wrap = $('#recentWrap');
    if (!events || !events.length) { wrap.hidden = true; return; }
    wrap.hidden = false;
    $('#recentList').innerHTML = events.map(function (e) {
      var l = (state && state.lockers || []).find(function (x) { return x.id === e.lockerId; });
      return '<li>🔓 <b>' + esc(l ? l.title : e.lockerId) + '</b>' +
        (e.telegram ? ' — @' + esc(e.telegram) : '') +
        ' <span class="muted">· ' + timeAgo(e.at) + '</span></li>';
    }).join('');
  }

  /* ---------------- events ---------------- */
  $('#loginForm').addEventListener('submit', function (e) {
    e.preventDefault();
    $('#lgErr').hidden = true;
    api('/api/login', {
      method: 'POST',
      body: JSON.stringify({ username: $('#lgUser').value, password: $('#lgPass').value })
    }).then(function (r) {
      if (r.ok) { $('#lgPass').value = ''; boot(); }
      else { $('#lgErr').textContent = r.error || 'লগইন ব্যর্থ'; $('#lgErr').hidden = false; }
    }).catch(function () {});
  });

  $('#btnLogout').addEventListener('click', function () {
    api('/api/logout', { method: 'POST' }).then(function () { showLogin(); });
  });

  document.querySelectorAll('.tab').forEach(function (t) {
    t.addEventListener('click', function () {
      document.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('active'); });
      t.classList.add('active');
      ['lockers', 'settings', 'help'].forEach(function (p) {
        $('#page-' + p).hidden = p !== t.dataset.tab;
      });
    });
  });

  $('#lockerList').addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-act]');
    if (!btn) return;
    var card = btn.closest('.locker');
    var id = card.dataset.id;
    var l = state.lockers.find(function (x) { return x.id === id; });
    var act = btn.dataset.act;

    if (act === 'copy') {
      copy(btn.dataset.url);
    } else if (act === 'open') {
      window.open(btn.dataset.url, '_blank', 'noopener');
    } else if (act === 'edit') {
      openEditor(l);
    } else if (act === 'toggle') {
      api('/api/lockers/' + id, { method: 'PUT', body: JSON.stringify({ active: !l.active }) })
        .then(function () { toast('আপডেট হয়েছে', 'ok'); boot(); });
    } else if (act === 'del') {
      if (!confirm('“' + l.title + '” ডিলিট করবেন?')) return;
      api('/api/lockers/' + id, { method: 'DELETE' }).then(function () { toast('ডিলিট হয়েছে', 'ok'); boot(); });
    }
  });

  function copy(text) {
    var done = function () { toast('📋 কপি হয়েছে', 'ok'); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else fallback();
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast('কপি করা যায়নি', 'err'); }
      document.body.removeChild(ta);
    }
  }

  /* ---------------- editor ---------------- */
  function taskRowHTML(t, i) {
    t = t || { type: 'telegram_channel', label: '', url: '', chatId: '', required: true };
    var opts = TYPES.map(function (o) {
      return '<option value="' + o.v + '"' + (o.v === t.type ? ' selected' : '') + '>' + o.t + '</option>';
    }).join('');
    var isTg = t.type.indexOf('telegram') === 0;
    return '' +
      '<div class="task-row" data-i="' + i + '">' +
        '<div class="task-row-head">' +
          '<select class="tr-type">' + opts + '</select>' +
          '<button class="icon-btn tr-del" title="সরান">🗑</button>' +
        '</div>' +
        '<label>টাস্কের নাম<input class="tr-label" type="text" value="' + esc(t.label) + '" placeholder="টেলিগ্রাম চ্যানেলে জয়েন করুন" /></label>' +
        '<div class="grid2">' +
          '<label>লিংক / URL<input class="tr-url" type="text" value="' + esc(t.url) + '" placeholder="https://t.me/yourchannel" /></label>' +
          '<label class="tr-chat-wrap"' + (isTg ? '' : ' hidden') + '>টেলিগ্রাম Chat ID <span class="hint">@channel বা -100123…</span>' +
            '<input class="tr-chat" type="text" value="' + esc(t.chatId) + '" placeholder="@yourchannel" /></label>' +
        '</div>' +
        '<label class="check"><input class="tr-req" type="checkbox"' + (t.required !== false ? ' checked' : '') + ' /> আনলকের জন্য বাধ্যতামূলক</label>' +
      '</div>';
  }

  function readTasks() {
    return [].slice.call(document.querySelectorAll('#taskRows .task-row')).map(function (row) {
      return {
        type: row.querySelector('.tr-type').value,
        label: row.querySelector('.tr-label').value.trim(),
        url: row.querySelector('.tr-url').value.trim(),
        chatId: row.querySelector('.tr-chat').value.trim(),
        required: row.querySelector('.tr-req').checked
      };
    }).filter(function (t) { return t.url || t.label; });
  }

  $('#taskRows').addEventListener('click', function (e) {
    if (e.target.closest('.tr-del')) {
      e.target.closest('.task-row').remove();
    }
  });

  $('#taskRows').addEventListener('change', function (e) {
    var sel = e.target.closest('.tr-type');
    if (!sel) return;
    var row = sel.closest('.task-row');
    var isTg = sel.value.indexOf('telegram') === 0;
    row.querySelector('.tr-chat-wrap').hidden = !isTg;
    var ph = {
      telegram_channel: ['টেলিগ্রাম চ্যানেলে সাবস্ক্রাইব করুন', 'https://t.me/yourchannel'],
      telegram_group: ['টেলিগ্রাম গ্রুপে জয়েন করুন', 'https://t.me/yourgroup'],
      youtube: ['ইউটিউব চ্যানেল সাবস্ক্রাইব করুন', 'https://youtube.com/@channel?sub_confirmation=1'],
      website: ['ওয়েবসাইট ভিজিট করুন', 'https://example.com'],
      custom: ['কাস্টম টাস্ক', 'https://']
    }[sel.value] || ['', ''];
    var label = row.querySelector('.tr-label'), url = row.querySelector('.tr-url');
    if (!label.value) label.placeholder = ph[0];
    if (!url.value) url.placeholder = ph[1];
  });

  $('#btnAddTask').addEventListener('click', function () {
    var rows = document.querySelectorAll('#taskRows .task-row').length;
    $('#taskRows').insertAdjacentHTML('beforeend', taskRowHTML(null, rows));
  });

  function openEditor(l) {
    editingId = l ? l.id : null;
    $('#modalTitle').textContent = l ? 'লকার এডিট করুন' : 'নতুন লকার';
    $('#fTitle').value = l ? l.title : '';
    $('#fDesc').value = l ? l.description : '';
    $('#fUrl').value = l ? l.targetUrl : '';
    $('#fSlug').value = l ? l.slug : '';
    $('#fCountdown').value = l ? l.countdown : (state.settings.defaultCountdown || 15);
    $('#fAuto').checked = l ? !!l.autoRedirect : false;
    $('#btnDeleteLocker').hidden = !l;

    var tasks = (l && l.tasks && l.tasks.length) ? l.tasks : [
      { type: 'telegram_channel', label: 'টেলিগ্রাম চ্যানেলে সাবস্ক্রাইব করুন', url: '', chatId: '', required: true },
      { type: 'youtube', label: 'ইউটিউব চ্যানেল সাবস্ক্রাইব করুন', url: '', required: true },
      { type: 'telegram_group', label: 'টেলিগ্রাম গ্রুপে জয়েন করুন', url: '', chatId: '', required: true }
    ];
    $('#taskRows').innerHTML = tasks.map(taskRowHTML).join('');
    $('#modal').hidden = false;
  }

  function closeEditor() { $('#modal').hidden = true; }
  $('#modalClose').addEventListener('click', closeEditor);
  $('#btnCancel').addEventListener('click', closeEditor);
  $('#btnNew').addEventListener('click', function () { openEditor(null); });

  $('#btnSaveLocker').addEventListener('click', function () {
    var payload = {
      title: $('#fTitle').value.trim() || 'আনলক করুন',
      description: $('#fDesc').value.trim(),
      targetUrl: $('#fUrl').value.trim(),
      slug: $('#fSlug').value.trim(),
      countdown: Number($('#fCountdown').value) || 15,
      autoRedirect: $('#fAuto').checked,
      tasks: readTasks()
    };
    if (!payload.targetUrl) return toast('টার্গেট লিংক দিন', 'err');
    if (!payload.tasks.length) return toast('অন্তত একটি টাস্ক যোগ করুন', 'err');

    var url = editingId ? '/api/lockers/' + editingId : '/api/lockers';
    var method = editingId ? 'PUT' : 'POST';
    api(url, { method: method, body: JSON.stringify(payload) }).then(function (r) {
      if (!r.ok) return toast(r.error || 'সেভ করা যায়নি', 'err');
      closeEditor();
      toast('✅ সেভ হয়েছে', 'ok');
      boot();
    });
  });

  $('#btnDeleteLocker').addEventListener('click', function () {
    if (!editingId || !confirm('এই লকারটি ডিলিট করবেন?')) return;
    api('/api/lockers/' + editingId, { method: 'DELETE' }).then(function () {
      closeEditor(); toast('ডিলিট হয়েছে', 'ok'); boot();
    });
  });

  /* ---------------- settings ---------------- */
  $('#btnSaveSettings').addEventListener('click', function () {
    var body = {
      siteName: $('#setSiteName').value.trim() || 'Link Locker',
      footerNote: $('#setFooter').value.trim(),
      defaultCountdown: Number($('#setCountdown').value) || 15,
      autoRedirectSeconds: Number($('#setRedirect').value) || 0,
      adminUsername: $('#setUser').value.trim() || 'admin',
      telegramBotToken: $('#setToken').value.trim(),
      adminChatId: $('#setAdminChat').value.trim()
    };
    if ($('#setPass').value) body.newPassword = $('#setPass').value;
    api('/api/settings', { method: 'POST', body: JSON.stringify(body) }).then(function (r) {
      if (!r.ok) return toast(r.error || 'সেভ করা যায়নি', 'err');
      toast('✅ সেটিংস সেভ হয়েছে', 'ok');
      boot();
    });
  });

  $('#btnTestBot').addEventListener('click', function () {
    var token = $('#setToken').value.trim();
    if (!token) return toast('আগে টোকেন দিন', 'err');
    $('#botStatus').textContent = 'যাচাই করা হচ্ছে…';
    api('/api/settings', { method: 'POST', body: JSON.stringify({ telegramBotToken: token }) })
      .then(function () {
        return api('/api/telegram/test', { method: 'POST' });
      })
      .then(function (r) {
        if (r.ok) toast('✅ বট সংযোগ সফল: @' + r.bot.username, 'ok');
        else toast('❌ ' + (r.error || 'সংযোগ ব্যর্থ'), 'err');
        boot();
      });
  });

  boot();
})();
