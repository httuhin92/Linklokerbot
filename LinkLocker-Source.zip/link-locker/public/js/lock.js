/* Link Locker — public locker page logic */
(function () {
  var L = window.LOCKER || {};
  var slug = L.slug;
  var countdown = L.countdown || 15;
  var total = L.total || 0;
  var required = L.required || [];
  var restored = L.restored || {};

  var tasksEl = document.getElementById('tasks');
  var bar = document.getElementById('bar');
  var doneCount = document.getElementById('doneCount');
  var unlockBtn = document.getElementById('unlockBtn');
  var unlockText = document.getElementById('unlockText');
  var unlockHint = document.getElementById('unlockHint');
  var reveal = document.getElementById('reveal');
  var finalUrl = document.getElementById('finalUrl');
  var openLink = document.getElementById('openLink');
  var copyBtn = document.getElementById('copyBtn');
  var redirectNote = document.getElementById('redirectNote');
  var toastEl = document.getElementById('toast');

  var items = [].slice.call(document.querySelectorAll('.task'));
  var state = {}; // index -> 'done' | 'busy'
  var timers = {};

  function toast(msg, kind) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.className = 'toast show' + (kind ? ' ' + kind : '');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () {
      toastEl.className = 'toast';
    }, 3200);
  }

  function post(url, body) {
    return fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body || {})
    }).then(function (r) { return r.json(); });
  }

  function refresh() {
    var done = 0;
    var need = 0;
    for (var i = 0; i < total; i++) {
      if (state[i] === 'done') done++;
      if (required[i] !== false) need++;
    }
    if (doneCount) doneCount.textContent = done;
    if (bar) bar.style.width = total ? (done / total) * 100 + '%' : '0%';
    var allRequiredDone = Object.keys(state).filter(function (k) { return state[k] === 'done'; }).length >= countRequired();
    if (unlockBtn && !state.__unlocked) {
      unlockBtn.disabled = !allRequiredDone;
      unlockBtn.classList.toggle('ready', allRequiredDone);
      unlockText.textContent = allRequiredDone ? '🔓 লিংক আনলক করুন' : 'সব কাজ শেষ করুন (' + done + '/' + countRequired() + ')';
      unlockHint.textContent = allRequiredDone ? 'সব কাজ সম্পন্ন হয়েছে — নিচে ক্লিক করুন' : 'সব টাস্ক সম্পন্ন করলে আনলক বাটন চালু হবে';
    }
    return allRequiredDone;
  }

  function countRequired() {
    var n = 0;
    for (var i = 0; i < total; i++) if (required[i] !== false) n++;
    return n;
  }

  function markDone(i, el) {
    state[i] = 'done';
    el.classList.add('done');
    el.classList.remove('active');
    var btn = el.querySelector('[data-act="start"]');
    var badge = el.querySelector('.verified-badge');
    if (btn) btn.hidden = true;
    if (badge) badge.hidden = false;
    refresh();
  }

  function busy(el, text) {
    var btn = el.querySelector('[data-act="start"]');
    if (!btn) return;
    if (text === null) {
      btn.classList.remove('waiting');
      btn.disabled = false;
      return;
    }
    btn.classList.add('waiting');
    btn.disabled = true;
    btn.textContent = text;
  }

  /* ---------- click/countdown mode ---------- */
  function startClick(i, el) {
    var url = L.urls[i];
    if (url) window.open(url, '_blank', 'noopener');
    el.classList.add('active');
    post('/api/l/' + slug + '/click', { taskIndex: i });

    var left = countdown;
    busy(el, '⏳ ' + left + 's');
    clearInterval(timers[i]);
    timers[i] = setInterval(function () {
      left--;
      if (left > 0) {
        busy(el, '⏳ ' + left + 's');
      } else {
        clearInterval(timers[i]);
        busy(el, 'চেক করা হচ্ছে…');
        post('/api/l/' + slug + '/verify-click', { taskIndex: i }).then(function (r) {
          if (r.ok) {
            markDone(i, el);
            toast('✅ ভেরিফাই হয়েছে!', 'ok');
          } else {
            busy(el, null);
            el.querySelector('[data-act="start"]').textContent = 'আবার চেষ্টা করুন';
            toast(r.error || 'ভেরিফাই হয়নি', 'err');
          }
        });
      }
    }, 1000);
  }

  /* ---------- telegram bot mode ---------- */
  function startTelegram(i, el) {
    busy(el, 'যাচাই করা হচ্ছে…');
    post('/api/l/' + slug + '/verify-telegram', { taskIndex: i }).then(function (r) {
      if (r.ok && r.instant) {
        markDone(i, el);
        toast('✅ ভেরিফাই হয়েছে!', 'ok');
        return;
      }
      if (r.ok && r.needCode) {
        window.open(r.botUrl, '_blank', 'noopener');
        busy(el, 'বটে START চাপুন…');
        poll(i, el, r.code);
        return;
      }
      busy(el, null);
      el.querySelector('[data-act="start"]').textContent = 'আবার চেষ্টা করুন';
      toast(r.error || 'ভেরিফাই করা যায়নি', 'err');
    });
  }

  function poll(i, el, code) {
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      if (tries > 100) {
        clearInterval(iv);
        busy(el, null);
        el.querySelector('[data-act="start"]').textContent = 'আবার চেষ্টা করুন';
        toast('সময় শেষ — আবার চেষ্টা করুন', 'err');
        return;
      }
      fetch('/api/verify/status/' + code + '?locker=' + encodeURIComponent(slug) + '&task=' + i)
        .then(function (r) { return r.json(); })
        .then(function (r) {
          if (!r.ok) return;
          if (!r.resolved) return;
          clearInterval(iv);
          if (r.member) {
            markDone(i, el);
            toast('✅ ' + (r.name ? r.name + ' — ' : '') + 'ভেরিফাই হয়েছে!', 'ok');
          } else {
            busy(el, null);
            el.querySelector('[data-act="start"]').textContent = 'আবার চেষ্টা করুন';
            toast('আপনি এখনো এই চ্যানেল/গ্রুপে যুক্ত হননি', 'err');
          }
        })
        .catch(function () {});
    }, 2500);
    timers[i] = iv;
  }

  /* ---------- wiring ---------- */
  items.forEach(function (el) {
    var i = Number(el.dataset.index);
    var mode = el.dataset.mode;
    var btn = el.querySelector('[data-act="start"]');

    if (restored[i] || restored[String(i)]) {
      markDone(i, el);
    }

    btn.addEventListener('click', function () {
      if (state[i] === 'done') return;
      if (mode === 'telegram' && L.botReady) startTelegram(i, el);
      else startClick(i, el);
    });
  });

  refresh();

  /* ---------- unlock ---------- */
  if (unlockBtn) {
    unlockBtn.addEventListener('click', function () {
      unlockBtn.disabled = true;
      unlockText.textContent = 'অপেক্ষা করুন…';
      post('/api/l/' + slug + '/unlock', {}).then(function (r) {
        if (!r.ok) {
          unlockBtn.disabled = false;
          toast(r.error || 'আনলক করা যায়নি', 'err');
          refresh();
          return;
        }
        state.__unlocked = true;
        unlockBtn.hidden = true;
        unlockHint.hidden = true;
        reveal.hidden = false;
        finalUrl.value = r.url;
        openLink.href = r.url;
        toast('🎉 লিংক আনলক হয়েছে!', 'ok');
        document.querySelector('.unlock-zone').scrollIntoView({ behavior: 'smooth', block: 'center' });

        if (L.autoRedirect > 0) {
          var s = L.autoRedirect;
          redirectNote.hidden = false;
          redirectNote.textContent = s + ' সেকেন্ডে স্বয়ংক্রিয়ভাবে লিংকে চলে যাবে…';
          openLink.click();
          var iv = setInterval(function () {
            s--;
            if (s <= 0) {
              clearInterval(iv);
              redirectNote.textContent = 'রিডাইরেক্ট করা হয়েছে।';
            } else {
              redirectNote.textContent = s + ' সেকেন্ডে স্বয়ংক্রিয়ভাবে লিংকে চলে যাবে…';
            }
          }, 1000);
        }
      });
    });
  }

  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      finalUrl.select();
      var done = function () { toast('📋 লিংক কপি হয়েছে', 'ok'); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(finalUrl.value).then(done, function () { document.execCommand('copy'); done(); });
      } else {
        finalUrl.setSelectionRange(0, 99999);
        document.execCommand('copy');
        done();
      }
    });
  }
})();
