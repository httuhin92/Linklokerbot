'use strict';
/**
 * খুবই সিম্পল JSON-ফাইল-ভিত্তিক স্টোর — কোনো ডেটাবেজ সেটআপ লাগবে না।
 * সব ডেটা থাকে: data/db.json
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DEFAULT_SETTINGS = {
  siteName: 'Link Locker',
  adminUsername: 'admin',
  adminPasswordHash: '',
  telegramBotToken: '',
  telegramBotUsername: '',
  adminChatId: '',
  defaultCountdown: 15,
  autoRedirectSeconds: 0,
  footerNote: ''
};

let db = null;
let writeTimer = null;

function hashPassword(password, salt) {
  const s = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), s, 64).toString('hex');
  return `scrypt:${s}:${hash}`;
}

function verifyPassword(password, stored) {
  if (!stored || !stored.startsWith('scrypt:')) return false;
  const [, salt, hash] = stored.split(':');
  const calc = crypto.scryptSync(String(password), salt, 64).toString('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(calc, 'hex'));
  } catch (e) {
    return false;
  }
}

function seed() {
  const pw = process.env.ADMIN_PASSWORD || 'admin123';
  return {
    settings: {
      ...DEFAULT_SETTINGS,
      adminPasswordHash: hashPassword(pw),
      telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
      telegramBotUsername: process.env.TELEGRAM_BOT_USERNAME || ''
    },
    lockers: [],
    events: [],
    meta: { createdAt: new Date().toISOString() }
  };
}

function load() {
  if (db) return db;
  if (fs.existsSync(DB_FILE)) {
    try {
      db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
      console.error('[store] db.json পড়তে সমস্যা, নতুন ফাইল তৈরি হচ্ছে:', e.message);
      db = seed();
    }
  } else {
    db = seed();
  }
  db.settings = { ...DEFAULT_SETTINGS, ...(db.settings || {}) };
  db.lockers = db.lockers || [];
  db.events = db.events || [];
  save();
  return db;
}

function save() {
  if (!db) return;
  clearTimeout(writeTimer);
  writeTimer = setTimeout(() => {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
    } catch (e) {
      console.error('[store] save failed:', e.message);
    }
  }, 120);
}

function flush() {
  clearTimeout(writeTimer);
  if (db) fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function getSettings() {
  return load().settings;
}

function updateSettings(patch) {
  const s = load().settings;
  Object.assign(s, patch);
  save();
  return s;
}

function listLockers() {
  return load().lockers;
}

function getLocker(idOrSlug) {
  return load().lockers.find((l) => l.id === idOrSlug || l.slug === idOrSlug) || null;
}

function randomId(len = 6) {
  let out = '';
  const chars = 'abcdefghijkmnpqrstuvwxyz23456789';
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function createLocker(payload) {
  const d = load();
  const slug = (payload.slug && String(payload.slug).trim()) || randomId(6);
  const locker = {
    id: randomId(10),
    slug: slug.replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase() || randomId(6),
    title: payload.title || 'Untitled Locker',
    description: payload.description || '',
    targetUrl: payload.targetUrl || '',
    tasks: Array.isArray(payload.tasks) ? payload.tasks : [],
    countdown: Number(payload.countdown) || 15,
    autoRedirect: !!payload.autoRedirect,
    active: payload.active !== false,
    visits: 0,
    unlocks: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  d.lockers.unshift(locker);
  save();
  return locker;
}

function updateLocker(id, patch) {
  const d = load();
  const idx = d.lockers.findIndex((l) => l.id === id || l.slug === id);
  if (idx === -1) return null;
  const allowed = ['title', 'description', 'targetUrl', 'tasks', 'countdown', 'autoRedirect', 'slug', 'active'];
  for (const k of allowed) if (k in patch) d.lockers[idx][k] = patch[k];
  d.lockers[idx].updatedAt = new Date().toISOString();
  save();
  return d.lockers[idx];
}

function deleteLocker(id) {
  const d = load();
  const idx = d.lockers.findIndex((l) => l.id === id || l.slug === id);
  if (idx === -1) return false;
  d.lockers.splice(idx, 1);
  save();
  return true;
}

function bumpVisits(id) {
  const l = getLocker(id);
  if (l) {
    l.visits = (l.visits || 0) + 1;
    save();
  }
}

function bumpUnlocks(id, extra = {}) {
  const d = load();
  const l = d.lockers.find((x) => x.id === id || x.slug === id);
  if (l) l.unlocks = (l.unlocks || 0) + 1;
  d.events.unshift({
    at: new Date().toISOString(),
    lockerId: id,
    type: 'unlock',
    ...extra
  });
  if (d.events.length > 500) d.events.length = 500;
  save();
}

module.exports = {
  load,
  save,
  flush,
  getSettings,
  updateSettings,
  listLockers,
  getLocker,
  createLocker,
  updateLocker,
  deleteLocker,
  bumpVisits,
  bumpUnlocks,
  hashPassword,
  verifyPassword,
  randomId
};
