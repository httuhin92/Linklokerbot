'use strict';
/**
 * Telegram Bot integration
 *  - লং-পলিং (getUpdates) দিয়ে ইউজারের Telegram User ID সংগ্রহ
 *  - getChatMember দিয়ে সত্যিই চ্যানেল/গ্রুপে আছে কিনা ভেরিফাই
 *
 * বট টোকেন না দিলে এই মডিউল নিজে থেকেই নিষ্ক্রিয় থাকে।
 */
const store = require('./store');

const pending = new Map(); // code -> { telegramUserId, username, firstName, at }
let offset = 0;
let polling = false;
let lastError = '';
let botInfo = null;

function enabled() {
  return !!(store.getSettings().telegramBotToken || '').trim();
}

async function api(method, body = {}, timeoutMs = 20000) {
  const token = (store.getSettings().telegramBotToken || '').trim();
  if (!token) throw new Error('Telegram bot token সেট করা নেই');
  const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeoutMs)
  });
  const json = await res.json();
  if (!json.ok) throw new Error(json.description || method + ' failed');
  return json.result;
}

/** কোনো চ্যাটের (চ্যানেল/গ্রুপ) ID জানিয়ে দেয় */
function sendChatInfo(targetChatId, chat) {
  const lines = [
    '🆔 Chat ID: ' + chat.id,
    '📂 ধরন: ' + chat.type,
    '📛 নাম: ' + (chat.title || chat.first_name || '—')
  ];
  if (chat.username) lines.push('🔗 @' + chat.username);
  lines.push('', '👉 এই ID টি লকারের "Telegram Chat ID" ঘরে দিন।');
  api('sendMessage', { chat_id: targetChatId, text: lines.join('\n') }).catch(() => {});
}

/** /start v_<code> → কোডের সাথে Telegram user id জুড়ে দেই */
function handleUpdate(u) {
  const msg = u.message || u.edited_message;
  if (!msg || !msg.from) return;
  const text = (msg.text || '').trim();
  const chatId = msg.chat.id;
  const user = msg.from;

  // ১) চ্যানেল/গ্রুপ থেকে কোনো পোস্ট ফরওয়ার্ড করলে → সেই চ্যাটের ID দেখিয়ে দেই
  const fo = msg.forward_origin;
  if (fo && (fo.type === 'channel' || fo.type === 'supergroup') && fo.chat) {
    sendChatInfo(chatId, fo.chat);
    return;
  }
  // ২) /id কমান্ড (গ্রুপে বটকে অ্যাডমিন বানিয়ে /id দিলে গ্রুপের ID পাওয়া যাবে)
  if (/^\/id(@\w+)?$/.test(text)) {
    sendChatInfo(chatId, msg.chat);
    return;
  }
  // ৩) ভেরিফিকেশন কোড
  const m = text.match(/^\/start\s+(?:v_)?([A-Za-z0-9_-]{4,32})$/);

  if (m) {
    const code = m.group ? m[1] : null;
    if (code) {
      pending.set(code, {
        telegramUserId: user.id,
        username: user.username || '',
        firstName: user.first_name || '',
        at: Date.now()
      });
      api('sendMessage', {
        chat_id: chatId,
        text:
          '✅ ভেরিফিকেশন কোড পেয়েছি!\n\nএখন ওয়েবসাইটের পেজে ফিরে গেলে স্বয়ংক্রিয়ভাবে চেক হয়ে যাবে। যদি কোনো টাস্ক বাকি থাকে, সেগুলোও সম্পন্ন করুন।',
        disable_web_page_preview: true
      }).catch(() => {});
      return;
    }
  }
  api('sendMessage', {
    chat_id: chatId,
    text:
      '👋 এই বটটি লিংক ভেরিফিকেশনের জন্য ব্যবহৃত হয়।\n\n' +
      '• ভেরিফাই করতে: ওয়েবসাইটের "ভেরিফাই করুন" বাটনে ক্লিক করুন\n' +
      '• চ্যানেল/গ্রুপের ID জানতে: ওই চ্যাট থেকে যেকোনো মেসেজ এখানে ফরওয়ার্ড করুন\n' +
      '• /id — বর্তমান চ্যাটের ID'
  }).catch(() => {});
}

/** অ্যাডমিনকে নোটিফিকেশন পাঠায় (adminChatId সেট করা থাকলে) */
function notifyAdmin(text) {
  const id = (store.getSettings().adminChatId || '').toString().trim();
  if (!id || !enabled()) return Promise.resolve(false);
  return api('sendMessage', { chat_id: id, text, disable_web_page_preview: true })
    .then(() => true)
    .catch(() => false);
}

async function loop() {
  if (polling) return;
  polling = true;
  while (true) {
    const token = (store.getSettings().telegramBotToken || '').trim();
    if (!token) {
      polling = false;
      setTimeout(() => start(), 5000).unref();
      return;
    }
    try {
      const updates = await api('getUpdates', { offset, timeout: 25, allowed_updates: ['message'] }, 45000);
      lastError = '';
      for (const u of updates) {
        offset = u.update_id + 1;
        try {
          handleUpdate(u);
        } catch (e) {
          /* ignore per-update errors */
        }
      }
    } catch (e) {
      lastError = e.message || String(e);
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

let started = false;
function start() {
  if (started) return;
  started = true;
  refreshBotInfo().then(() => loop());
  setInterval(() => refreshBotInfo(), 10 * 60 * 1000).unref();
}

async function refreshBotInfo() {
  if (!enabled()) {
    botInfo = null;
    return null;
  }
  try {
    botInfo = await api('getMe');
    // লং-পলিং কাজ করবে — আগে কোনো webhook সেট থাকলে সরিয়ে দিই
    await api('deleteWebhook', { drop_pending_updates: false }).catch(() => {});
    if (botInfo && botInfo.username) {
      const s = store.getSettings();
      if (s.telegramBotUsername !== botInfo.username) {
        store.updateSettings({ telegramBotUsername: botInfo.username });
      }
    }
    return botInfo;
  } catch (e) {
    lastError = e.message;
    botInfo = null;
    return null;
  }
}

function botUsername() {
  const s = store.getSettings();
  return (s.telegramBotUsername || (botInfo && botInfo.username) || '').replace(/^@/, '');
}

/** নতুন ভেরিফিকেশন কোড তৈরি */
function newCode() {
  const code = store.randomId(12);
  return code;
}

function getPending(code) {
  const p = pending.get(code);
  if (!p) return null;
  if (Date.now() - p.at > 10 * 60 * 1000) {
    pending.delete(code);
    return null;
  }
  return p;
}

function clearPending(code) {
  pending.delete(code);
}

const OK_STATUSES = ['creator', 'administrator', 'member', 'restricted'];

/** ইউজার সত্যিই চ্যাটে (চ্যানেল/গ্রুপ) আছে কিনা */
async function isMember(chatId, telegramUserId) {
  try {
    const r = await api('getChatMember', { chat_id: chatId, user_id: telegramUserId });
    return { ok: OK_STATUSES.includes(r.status), status: r.status };
  } catch (e) {
    return { ok: false, status: 'error', error: e.message };
  }
}

function status() {
  return {
    enabled: enabled(),
    botUsername: botUsername(),
    lastError,
    pendingCount: pending.size
  };
}

module.exports = { start, status, newCode, getPending, clearPending, isMember, botUsername, refreshBotInfo, enabled, notifyAdmin };
