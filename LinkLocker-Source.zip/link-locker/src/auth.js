'use strict';
const crypto = require('crypto');
const store = require('./store');

// In-memory সেশন (সার্ভার রিস্টার্ট হলে লগআউট হয়ে যাবে — ছোট অ্যাপের জন্য যথেষ্ট)
const sessions = new Map(); // token -> { createdAt, ip }
const SESSION_TTL = 1000 * 60 * 60 * 24 * 7; // ৭ দিন

function createSession() {
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, { createdAt: Date.now() });
  return token;
}

function destroySession(token) {
  sessions.delete(token);
}

function isValid(token) {
  if (!token) return false;
  const s = sessions.get(token);
  if (!s) return false;
  if (Date.now() - s.createdAt > SESSION_TTL) {
    sessions.delete(token);
    return false;
  }
  return true;
}

function login(username, password) {
  const s = store.getSettings();
  if (username !== s.adminUsername) return null;
  if (!store.verifyPassword(password, s.adminPasswordHash)) return null;
  return createSession();
}

function attach(req, res, next) {
  req.adminToken = req.cookies && req.cookies.lk_admin;
  req.isAdmin = isValid(req.adminToken);
  next();
}

function requireAdmin(req, res, next) {
  if (!req.isAdmin) {
    return res.status(401).json({ ok: false, error: 'লগইন প্রয়োজন' });
  }
  next();
}

function cleanup() {
  for (const [t, s] of sessions) {
    if (Date.now() - s.createdAt > SESSION_TTL) sessions.delete(t);
  }
}
setInterval(cleanup, 1000 * 60 * 60).unref();

module.exports = { login, attach, requireAdmin, createSession, destroySession, isValid };
