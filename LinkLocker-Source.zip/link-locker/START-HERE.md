# 🚀 শুরু করার আগে — ২ মিনিটের গাইড

## 📦 জিপে কী কী আছে

```
link-locker/
├── server.js          → মূল সার্ভার
├── src/               → store.js, auth.js, telegram.js
├── views/             → lock.ejs, message.ejs (ভিজিটর পেজ)
├── public/            → admin.html + css + js (অ্য্যাডমিন প্যানেল)
├── data/db.json       → ⚠️ আপনার সব সেটিং + লকার (আগেই কনফিগার করা!)
├── package.json
└── node_modules/      → শুধু "Full" ভার্সনে আছে
```

## ✅ আপনার তথ্য আগেই বসানো আছে

| আইটেম | মান |
|---|---|
| অ্যাডমিন প্যানেল | `/admin` |
| ইউজারনেম | `admin` |
| পাসওয়ার্ড | `tuhin.92` |
| টেলিগ্রাম বট | `@link_locker92_bot` ✅ সংযুক্ত |
| নোটিফিকেশন চ্যাট | `7290406614` (আপনার টেলিগ্রাম) |
| ডেমো লকার | `/l/demo` (৪টি টাস্ক) |
| চ্যানেল ১ | @modbox92 |
| গ্রুপ | @modboxcat |
| চ্যানেল ২ (ব্যাকআপ) | @myapk00 |
| ইউটিউব | @httuhinyt |

---

## 🏃 দ্রুত চালু (লোকাল টেস্ট)

```bash
cd link-locker
npm install          # শুধু "Source" ভার্সনে দরকার
npm start
```
→ ব্রাউজারে খুলুন: **http://localhost:3000/admin**

---

## 🌍 লাইভ করা (৩টি উপায়)

### উপায় ১: Railway.app — ⭐ সবচেয়ে সহজ, ফ্রি টিয়ার আছে

1. [railway.app](https://railway.app) → GitHub দিয়ে লগইন
2. **New Project** → **Deploy from GitHub** (রিপো বানাতে হবে) অথবা **Empty Project**
3. এই ফোল্ডারটি আপলোড/কানেক্ট করুন
4. Railway নিজে থেকে `npm install` + `npm start` চালিয়ে দেবে
5. **Settings → Networking → Generate Domain** → লিংক পাবেন, যেমন `https://yourapp.up.railway.app`
6. **Variables** ট্যাবে যোগ করুন (ঐচ্ছিক): `ADMIN_PASSWORD=tuhin.92`

> ⚠️ Railway-এ ডেটা (`data/db.json`) রিস্টার্টে মুছে যেতে পারে। ফ্রি প্ল্যানে ভলিউম মাউন্ট করুন অথবা নিয়মিত ব্যাকআপ নিন। পরে SQLite/Postgres-এ নেওয়া যাবে।

### উপায় ২: Render.com — ফ্রি টিয়ার + স্থায়ী ডিস্ক

1. [render.com](https://render.com) → **New → Web Service**
2. রিপো কানেক্ট করুন
3. **Build Command:** `npm install` · **Start Command:** `npm start`
4. **Environment:** `Node` · Instance type: **Free**
5. **Advanced → Add Disk:** Mount Path = `/opt/render/project/src/data`, Size = 1GB
   (এতে `data/db.json` টিকে থাকবে)
6. **Create Web Service** → কিছুক্ষণ পর `https://yourapp.onrender.com` পাবেন

### উপায় ৩: নিজের VPS (Ubuntu) — সবচেয়ে নির্ভরযোগ্য

```bash
# ১) Node.js 20+ ইনস্টল
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# ২) প্রজেক্ট আপলোড (FileZilla দিয়ে অথবা git clone)
cd /var/www/link-locker
npm install

# ৩) pm2 দিয়ে সার্ভার চালু রাখুন
sudo npm i -g pm2
pm2 start server.js --name link-locker
pm2 startup && pm2 save

# ৪) Nginx দিয়ে ডোমেইন + HTTPS (Certbot)
sudo apt install -y nginx certbot python3-certbot-nginx
# /etc/nginx/sites-available/locker:
#   server {
#     server_name yourdomain.com;
#     location / { proxy_pass http://127.0.0.1:3000;
#                  proxy_set_header Host $host;
#                  proxy_set_header X-Forwarded-Proto $scheme; }
#   }
sudo certbot --nginx -d yourdomain.com
```

### উপায় ৪: cPanel / শেয়ার্ড হোস্টিং (Node.js সাপোর্ট থাকলে)

1. cPanel → **Setup Node.js App** → **Create Application**
2. Node.js version: **20** · Application root: `link-locker` · Startup file: `server.js`
3. **Run NPM Install** ক্লিক করুন
4. **Start App** → ডোমেইনে লাইভ

---

## 🔴 লাইভ করার পর অবশ্যই করুন (চেকলিস্ট)

- [ ] **১. বটকে ৩ জায়গায় অ্যাডমিন বানান** ⚠️ সবচেয়ে জরুরি
  - [ ] `@modbox92` চ্যানেল → Administrators → Add Admin → `@link_locker92_bot`
  - [ ] `@modboxcat` গ্রুপ → Add Member → `@link_locker92_bot`
  - [ ] `@myapk00` চ্যানেল → Administrators → Add Admin → `@link_locker92_bot`
- [ ] **২. HTTPS চালু আছে কিনা দেখুন** (Railway/Render-এ অটোমেটিক) — HTTPS ছাড়া টেলিগ্রাম ভেরিফিকেশন কাজ করবে না
- [ ] **৩. লগইন করে পাসওয়ার্ড ঠিক আছে কিনা দেখুন** (`admin` / `tuhin.92`)
- [ ] **৪. `/l/demo` টেস্ট করুন** — ৪টি টাস্ক শেষ করে লিংক আনলক হচ্ছে কিনা
- [ ] **৫. টার্গেট লিংক বদলান** — অ্যাডমিন → লকার Edit → "টার্গেট লিংক" ঘরে আপনার আসল লিংক
- [ ] **৬. নতুন লকার তৈরি করুন** — প্রতি অফারের জন্য আলাদা লকার + স্লাগ
- [ ] **৭. `data/db.json` ব্যাকআপ রাখুন** — সব ডেটা এই এক ফাইলে

---

## 🔐 নিরাপত্তা

- ⚠️ এই জিপে আপনার **টেলিগ্রাম বট টোকেন** আছে (`data/db.json`) — **কারও সাথে শেয়ার করবেন না**
- টোকেন লিক হয়ে গেলে: Telegram-এ **@BotFather** → `/revoke` → নতুন টোকেন → অ্যাডমিন সেটিংসে বসান
- পাসওয়ার্ড ভুলে গেলে: `data/db.json` ডিলিট → ডিফল্ট `admin123` ফিরে আসবে (লকারগুলোও মুছে যাবে)

---

## 🆘 সমস্যা হলে

| সমস্যা | সমাধান |
|---|---|
| "আপনি এখনো যুক্ত হননি" | বট ওই চ্যানেল/গ্রুপের **Admin** নয় — উপরের চেকলিস্ট-১ দেখুন |
| বট সংযোগ হচ্ছে না | সেটিংস → Bot Token ঠিক আছে কিনা দেখুন → "বট টেস্ট করুন" |
| ভিজিট ০ দেখাচ্ছে | লিংক শেয়ার করে অন্য ব্রাউজার/ইনকগনিটোতে খুলুন |
| ৫০২/অ্যাপ বন্ধ | `pm2 logs link-locker` দেখুন (VPS) বা হোস্টিংয়ের Logs ট্যাব |
| পোর্ট error | `PORT=3001 npm start` দিয়ে আলাদা পোর্টে চালান |
